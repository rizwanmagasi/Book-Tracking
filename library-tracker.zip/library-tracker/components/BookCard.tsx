import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";

import { Book, getBookStatus } from "@/context/BooksContext";
import { useColors } from "@/hooks/useColors";

interface BookCardProps {
  book: Book;
  compact?: boolean;
}

export function BookCard({ book, compact = false }: BookCardProps) {
  const colors = useColors();
  const router = useRouter();
  const status = getBookStatus(book);

  const handlePress = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push({ pathname: "/book/[id]", params: { id: book.id } });
  };

  return (
    <Pressable
      onPress={handlePress}
      style={({ pressed }) => [
        styles.card,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          borderRadius: colors.radius,
        },
        pressed && { opacity: 0.82 },
      ]}
    >
      <View
        style={[
          styles.spine,
          {
            backgroundColor: book.coverColor,
            borderTopLeftRadius: colors.radius,
            borderBottomLeftRadius: colors.radius,
          },
        ]}
      />

      <View style={styles.content}>
        <View style={styles.titleRow}>
          <Text
            style={[styles.title, { color: colors.foreground }]}
            numberOfLines={compact ? 1 : 2}
          >
            {book.title}
          </Text>
          <View
            style={[
              styles.badge,
              { backgroundColor: status.color + "20" },
            ]}
          >
            <Text style={[styles.badgeText, { color: status.color }]}>
              {status.label}
            </Text>
          </View>
        </View>

        <Text
          style={[styles.author, { color: colors.mutedForeground }]}
          numberOfLines={1}
        >
          {book.author}
        </Text>

        {!compact && (
          <View style={styles.footer}>
            <View style={styles.metaItem}>
              <Ionicons
                name="library-outline"
                size={12}
                color={colors.mutedForeground}
              />
              <Text
                style={[styles.meta, { color: colors.mutedForeground }]}
                numberOfLines={1}
              >
                {book.library}
              </Text>
            </View>
            <View style={styles.metaItem}>
              <Ionicons
                name="calendar-outline"
                size={12}
                color={colors.mutedForeground}
              />
              <Text style={[styles.meta, { color: colors.mutedForeground }]}>
                Due{" "}
                {new Date(book.dueDate).toLocaleDateString("en-US", {
                  month: "short",
                  day: "numeric",
                })}
              </Text>
            </View>
          </View>
        )}
      </View>

      <Ionicons
        name="chevron-forward"
        size={16}
        color={colors.border}
        style={styles.arrow}
      />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
    borderWidth: 1,
    overflow: "hidden",
  },
  spine: {
    width: 6,
    alignSelf: "stretch",
  },
  content: {
    flex: 1,
    paddingHorizontal: 14,
    paddingVertical: 12,
    gap: 3,
  },
  titleRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 8,
    justifyContent: "space-between",
  },
  title: {
    flex: 1,
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
    lineHeight: 20,
  },
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 20,
    flexShrink: 0,
  },
  badgeText: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
  },
  author: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
  },
  footer: {
    flexDirection: "row",
    gap: 14,
    marginTop: 6,
  },
  metaItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  meta: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
  },
  arrow: {
    marginRight: 12,
  },
});
