import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useLocalSearchParams, useRouter } from "expo-router";
import React, { useMemo, useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import {
  getDaysUntilDue,
  getBookStatus,
  useBooks,
} from "@/context/BooksContext";
import { useColors } from "@/hooks/useColors";

export default function BookDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { books, returnBook, deleteBook, updateBook } = useBooks();
  const colors = useColors();
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const book = useMemo(
    () => books.find((b) => b.id === id),
    [books, id]
  );

  const [editingNotes, setEditingNotes] = useState(false);
  const [notes, setNotes] = useState(book?.notes ?? "");

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  if (!book) {
    return (
      <View
        style={[
          styles.center,
          { backgroundColor: colors.background, paddingTop: topPad },
        ]}
      >
        <Ionicons name="book-outline" size={48} color={colors.mutedForeground} />
        <Text style={[styles.notFound, { color: colors.mutedForeground }]}>
          Book not found
        </Text>
        <Pressable onPress={() => router.back()}>
          <Text style={[styles.back, { color: colors.primary }]}>Go back</Text>
        </Pressable>
      </View>
    );
  }

  const status = getBookStatus(book);
  const daysLeft = book.status === "active" ? getDaysUntilDue(book.dueDate) : null;

  async function handleReturn() {
    Alert.alert("Mark as returned", `Return "${book!.title}"?`, [
      { text: "Cancel", style: "cancel" },
      {
        text: "Return",
        onPress: async () => {
          await returnBook(book!.id);
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          router.back();
        },
      },
    ]);
  }

  async function handleDelete() {
    Alert.alert(
      "Delete book",
      `Remove "${book!.title}" from your tracker? This cannot be undone.`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            await deleteBook(book!.id);
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
            router.back();
          },
        },
      ]
    );
  }

  async function handleSaveNotes() {
    await updateBook(book!.id, { notes });
    setEditingNotes(false);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  }

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={[
        styles.content,
        {
          paddingTop: topPad + 8,
          paddingBottom:
            Platform.OS === "web" ? 34 + 40 : insets.bottom + 40,
        },
      ]}
      showsVerticalScrollIndicator={false}
    >
      {/* Back + Delete */}
      <View style={styles.topBar}>
        <Pressable
          onPress={() => router.back()}
          style={({ pressed }) => [pressed && { opacity: 0.6 }]}
        >
          <Ionicons name="arrow-back" size={24} color={colors.foreground} />
        </Pressable>
        <Pressable
          onPress={handleDelete}
          style={({ pressed }) => [pressed && { opacity: 0.6 }]}
        >
          <Ionicons name="trash-outline" size={22} color={colors.destructive} />
        </Pressable>
      </View>

      {/* Cover + title */}
      <View style={styles.heroRow}>
        <View
          style={[
            styles.cover,
            {
              backgroundColor: book.coverColor,
              borderRadius: colors.radius,
            },
          ]}
        >
          <Ionicons name="book" size={36} color="rgba(255,255,255,0.7)" />
        </View>
        <View style={styles.titleBlock}>
          <Text style={[styles.bookTitle, { color: colors.foreground }]}>
            {book.title}
          </Text>
          <Text style={[styles.bookAuthor, { color: colors.mutedForeground }]}>
            {book.author}
          </Text>
          <View
            style={[
              styles.statusBadge,
              { backgroundColor: status.color + "20", borderRadius: 20 },
            ]}
          >
            <Text style={[styles.statusText, { color: status.color }]}>
              {status.label}
            </Text>
          </View>
        </View>
      </View>

      {/* Due date countdown */}
      {book.status === "active" && daysLeft !== null && (
        <View
          style={[
            styles.countdownBox,
            {
              backgroundColor:
                daysLeft < 0
                  ? colors.destructive + "12"
                  : daysLeft <= 3
                  ? "#E67E2212"
                  : colors.accent + "12",
              borderColor:
                daysLeft < 0
                  ? colors.destructive + "40"
                  : daysLeft <= 3
                  ? "#E67E2240"
                  : colors.accent + "40",
              borderRadius: colors.radius,
            },
          ]}
        >
          <Ionicons
            name={daysLeft < 0 ? "warning" : "time-outline"}
            size={24}
            color={
              daysLeft < 0
                ? colors.destructive
                : daysLeft <= 3
                ? "#E67E22"
                : colors.accent
            }
          />
          <View>
            <Text
              style={[
                styles.countdownNum,
                {
                  color:
                    daysLeft < 0
                      ? colors.destructive
                      : daysLeft <= 3
                      ? "#E67E22"
                      : colors.accent,
                },
              ]}
            >
              {daysLeft === 0
                ? "Due today"
                : daysLeft < 0
                ? `${Math.abs(daysLeft)} days overdue`
                : `${daysLeft} days remaining`}
            </Text>
            <Text
              style={[styles.countdownSub, { color: colors.mutedForeground }]}
            >
              Due{" "}
              {new Date(book.dueDate).toLocaleDateString("en-US", {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </Text>
          </View>
        </View>
      )}

      {/* Info rows */}
      <View
        style={[
          styles.infoCard,
          {
            backgroundColor: colors.card,
            borderColor: colors.border,
            borderRadius: colors.radius,
          },
        ]}
      >
        <InfoRow
          icon="library-outline"
          label="Library"
          value={book.library}
          colors={colors}
        />
        <View
          style={[styles.divider, { backgroundColor: colors.border }]}
        />
        <InfoRow
          icon="calendar-outline"
          label="Borrowed"
          value={new Date(book.borrowDate).toLocaleDateString("en-US", {
            month: "long",
            day: "numeric",
            year: "numeric",
          })}
          colors={colors}
        />
        <View
          style={[styles.divider, { backgroundColor: colors.border }]}
        />
        <InfoRow
          icon="time-outline"
          label="Due"
          value={new Date(book.dueDate).toLocaleDateString("en-US", {
            month: "long",
            day: "numeric",
            year: "numeric",
          })}
          colors={colors}
        />
        {book.returnedDate && (
          <>
            <View
              style={[styles.divider, { backgroundColor: colors.border }]}
            />
            <InfoRow
              icon="checkmark-circle-outline"
              label="Returned"
              value={new Date(book.returnedDate).toLocaleDateString("en-US", {
                month: "long",
                day: "numeric",
                year: "numeric",
              })}
              colors={colors}
            />
          </>
        )}
      </View>

      {/* Notes */}
      <View style={styles.notesSection}>
        <View style={styles.notesHeader}>
          <Text style={[styles.notesLabel, { color: colors.foreground }]}>
            Notes
          </Text>
          {!editingNotes ? (
            <Pressable
              onPress={() => {
                setNotes(book.notes);
                setEditingNotes(true);
              }}
              style={({ pressed }) => [pressed && { opacity: 0.6 }]}
            >
              <Ionicons
                name="pencil-outline"
                size={18}
                color={colors.primary}
              />
            </Pressable>
          ) : (
            <View style={styles.notesBtns}>
              <Pressable
                onPress={() => setEditingNotes(false)}
                style={({ pressed }) => [pressed && { opacity: 0.6 }]}
              >
                <Ionicons
                  name="close-outline"
                  size={22}
                  color={colors.mutedForeground}
                />
              </Pressable>
              <Pressable
                onPress={handleSaveNotes}
                style={({ pressed }) => [pressed && { opacity: 0.6 }]}
              >
                <Ionicons
                  name="checkmark-outline"
                  size={22}
                  color={colors.primary}
                />
              </Pressable>
            </View>
          )}
        </View>
        {editingNotes ? (
          <TextInput
            style={[
              styles.notesInput,
              {
                backgroundColor: colors.card,
                borderColor: colors.primary,
                color: colors.foreground,
                borderRadius: colors.radius,
                fontFamily: "Inter_400Regular",
              },
            ]}
            value={notes}
            onChangeText={setNotes}
            multiline
            placeholder="Add notes about this book..."
            placeholderTextColor={colors.mutedForeground}
            textAlignVertical="top"
            autoFocus
          />
        ) : (
          <Text
            style={[
              styles.notesText,
              {
                color: book.notes
                  ? colors.foreground
                  : colors.mutedForeground,
              },
            ]}
          >
            {book.notes || "No notes yet. Tap the pencil to add one."}
          </Text>
        )}
      </View>

      {/* Return button */}
      {book.status === "active" && (
        <Pressable
          onPress={handleReturn}
          style={({ pressed }) => [
            styles.returnBtn,
            {
              backgroundColor: colors.accent,
              borderRadius: colors.radius,
            },
            pressed && { opacity: 0.85 },
          ]}
        >
          <Ionicons
            name="checkmark-circle-outline"
            size={20}
            color="#FFFFFF"
          />
          <Text style={styles.returnBtnText}>Mark as Returned</Text>
        </Pressable>
      )}
    </ScrollView>
  );
}

function InfoRow({
  icon,
  label,
  value,
  colors,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  value: string;
  colors: ReturnType<typeof import("@/hooks/useColors").useColors>;
}) {
  return (
    <View style={styles.infoRow}>
      <Ionicons name={icon} size={18} color={colors.mutedForeground} />
      <View style={styles.infoText}>
        <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>
          {label}
        </Text>
        <Text style={[styles.infoValue, { color: colors.foreground }]}>
          {value}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingHorizontal: 16 },
  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
  },
  notFound: { fontSize: 16, fontFamily: "Inter_400Regular" },
  back: { fontSize: 15, fontFamily: "Inter_500Medium" },
  topBar: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
  },
  heroRow: {
    flexDirection: "row",
    gap: 16,
    marginBottom: 20,
  },
  cover: {
    width: 88,
    height: 120,
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  titleBlock: {
    flex: 1,
    justifyContent: "center",
    gap: 6,
  },
  bookTitle: {
    fontSize: 20,
    fontFamily: "Inter_700Bold",
    lineHeight: 26,
  },
  bookAuthor: {
    fontSize: 15,
    fontFamily: "Inter_400Regular",
  },
  statusBadge: {
    alignSelf: "flex-start",
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  statusText: {
    fontSize: 12,
    fontFamily: "Inter_600SemiBold",
  },
  countdownBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
    padding: 16,
    borderWidth: 1,
    marginBottom: 16,
  },
  countdownNum: {
    fontSize: 16,
    fontFamily: "Inter_700Bold",
  },
  countdownSub: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    marginTop: 2,
  },
  infoCard: {
    borderWidth: 1,
    marginBottom: 20,
    overflow: "hidden",
  },
  infoRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  infoText: { flex: 1 },
  infoLabel: {
    fontSize: 11,
    fontFamily: "Inter_500Medium",
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  infoValue: {
    fontSize: 15,
    fontFamily: "Inter_500Medium",
    marginTop: 2,
  },
  divider: { height: 1, marginHorizontal: 16 },
  notesSection: { marginBottom: 24 },
  notesHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  notesLabel: {
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
  },
  notesBtns: { flexDirection: "row", gap: 12 },
  notesText: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    lineHeight: 22,
  },
  notesInput: {
    borderWidth: 1.5,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 14,
    minHeight: 100,
  },
  returnBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 15,
    marginBottom: 12,
  },
  returnBtnText: {
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
    color: "#FFFFFF",
  },
});
