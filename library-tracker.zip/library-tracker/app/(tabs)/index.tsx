import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React, { useMemo } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { BookCard } from "@/components/BookCard";
import { StatCard } from "@/components/StatCard";
import { getDaysUntilDue, useBooks } from "@/context/BooksContext";
import { useColors } from "@/hooks/useColors";

export default function HomeScreen() {
  const colors = useColors();
  const { books, loading } = useBooks();
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const stats = useMemo(() => {
    const active = books.filter((b) => b.status === "active");
    const returned = books.filter((b) => b.status === "returned");
    const overdue = active.filter((b) => getDaysUntilDue(b.dueDate) < 0);
    const dueSoon = active.filter((b) => {
      const d = getDaysUntilDue(b.dueDate);
      return d >= 0 && d <= 3;
    });
    return {
      total: books.length,
      active: active.length,
      returned: returned.length,
      overdue: overdue.length,
      dueSoon: dueSoon.length,
    };
  }, [books]);

  const recentActive = useMemo(
    () => books.filter((b) => b.status === "active").slice(0, 3),
    [books]
  );

  const overdueBooks = useMemo(
    () =>
      books
        .filter(
          (b) => b.status === "active" && getDaysUntilDue(b.dueDate) < 0
        )
        .slice(0, 2),
    [books]
  );

  const topPad =
    Platform.OS === "web" ? 67 : insets.top;

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={[
        styles.content,
        {
          paddingTop: topPad + 16,
          paddingBottom:
            Platform.OS === "web" ? 34 + 80 : insets.bottom + 100,
        },
      ]}
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={[styles.greeting, { color: colors.mutedForeground }]}>
            Welcome back
          </Text>
          <Text style={[styles.title, { color: colors.foreground }]}>
            My Library
          </Text>
        </View>
        <Pressable
          onPress={() => router.push("/(tabs)/add")}
          style={({ pressed }) => [
            styles.addBtn,
            { backgroundColor: colors.primary, borderRadius: colors.radius },
            pressed && { opacity: 0.8 },
          ]}
        >
          <Ionicons name="add" size={22} color={colors.primaryForeground} />
        </Pressable>
      </View>

      {/* Stats */}
      <View style={styles.statsRow}>
        <StatCard
          label="Total Books"
          value={stats.total}
          iconName="book-outline"
          color={colors.primary}
        />
        <StatCard
          label="Active"
          value={stats.active}
          iconName="time-outline"
          color={colors.accent}
        />
        <StatCard
          label="Due Soon"
          value={stats.dueSoon}
          iconName="alert-circle-outline"
          color={colors.warning}
        />
        <StatCard
          label="Overdue"
          value={stats.overdue}
          iconName="warning-outline"
          color={colors.destructive}
        />
      </View>

      {/* Overdue alert */}
      {overdueBooks.length > 0 && (
        <View
          style={[
            styles.alertBox,
            {
              backgroundColor: colors.destructive + "12",
              borderColor: colors.destructive + "40",
              borderRadius: colors.radius,
            },
          ]}
        >
          <View style={styles.alertHeader}>
            <Ionicons
              name="warning"
              size={16}
              color={colors.destructive}
            />
            <Text style={[styles.alertTitle, { color: colors.destructive }]}>
              Overdue Books
            </Text>
          </View>
          {overdueBooks.map((b) => (
            <BookCard key={b.id} book={b} compact />
          ))}
        </View>
      )}

      {/* Recent borrowed */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            Currently Borrowed
          </Text>
          {stats.active > 3 && (
            <Pressable onPress={() => router.push("/(tabs)/books")}>
              <Text style={[styles.seeAll, { color: colors.primary }]}>
                See all
              </Text>
            </Pressable>
          )}
        </View>

        {loading ? (
          <View style={styles.emptyState}>
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
              Loading...
            </Text>
          </View>
        ) : recentActive.length === 0 ? (
          <View
            style={[
              styles.emptyState,
              {
                backgroundColor: colors.card,
                borderColor: colors.border,
                borderRadius: colors.radius,
              },
            ]}
          >
            <Ionicons
              name="book-outline"
              size={36}
              color={colors.mutedForeground}
            />
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
              No books yet
            </Text>
            <Text
              style={[styles.emptyText, { color: colors.mutedForeground }]}
            >
              Tap + to track your first borrowed book
            </Text>
          </View>
        ) : (
          recentActive.map((book) => (
            <BookCard key={book.id} book={book} />
          ))
        )}
      </View>

      {/* Returned summary */}
      {stats.returned > 0 && (
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              Reading History
            </Text>
            <Pressable onPress={() => router.push("/(tabs)/history")}>
              <Text style={[styles.seeAll, { color: colors.primary }]}>
                View all
              </Text>
            </Pressable>
          </View>
          <Pressable
            onPress={() => router.push("/(tabs)/history")}
            style={({ pressed }) => [
              styles.historyTile,
              {
                backgroundColor: colors.card,
                borderColor: colors.border,
                borderRadius: colors.radius,
              },
              pressed && { opacity: 0.82 },
            ]}
          >
            <Ionicons
              name="checkmark-circle"
              size={24}
              color={colors.success}
            />
            <Text style={[styles.historyText, { color: colors.foreground }]}>
              {stats.returned} book{stats.returned !== 1 ? "s" : ""} returned
            </Text>
            <Ionicons
              name="chevron-forward"
              size={16}
              color={colors.mutedForeground}
            />
          </Pressable>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingHorizontal: 16 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 20,
  },
  greeting: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    marginBottom: 2,
  },
  title: {
    fontSize: 28,
    fontFamily: "Inter_700Bold",
  },
  addBtn: {
    width: 42,
    height: 42,
    alignItems: "center",
    justifyContent: "center",
  },
  statsRow: {
    flexDirection: "row",
    gap: 8,
    marginBottom: 20,
  },
  alertBox: {
    borderWidth: 1,
    padding: 12,
    marginBottom: 20,
    gap: 8,
  },
  alertHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    marginBottom: 4,
  },
  alertTitle: {
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
  },
  section: { marginBottom: 24 },
  sectionHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 17,
    fontFamily: "Inter_600SemiBold",
  },
  seeAll: {
    fontSize: 14,
    fontFamily: "Inter_500Medium",
  },
  emptyState: {
    borderWidth: 1,
    padding: 32,
    alignItems: "center",
    gap: 8,
  },
  emptyTitle: {
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
    marginTop: 4,
  },
  emptyText: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
  },
  historyTile: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 16,
    borderWidth: 1,
  },
  historyText: {
    flex: 1,
    fontSize: 15,
    fontFamily: "Inter_500Medium",
  },
});
