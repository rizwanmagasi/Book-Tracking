import { Ionicons } from "@expo/vector-icons";
import React, { useMemo } from "react";
import {
  FlatList,
  Platform,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { BookCard } from "@/components/BookCard";
import { Book, useBooks } from "@/context/BooksContext";
import { useColors } from "@/hooks/useColors";

export default function HistoryScreen() {
  const colors = useColors();
  const { books } = useBooks();
  const insets = useSafeAreaInsets();

  const returned = useMemo(
    () =>
      [...books.filter((b) => b.status === "returned")].sort((a, b) => {
        const aDate = a.returnedDate ?? a.borrowDate;
        const bDate = b.returnedDate ?? b.borrowDate;
        return new Date(bDate).getTime() - new Date(aDate).getTime();
      }),
    [books]
  );

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  function renderItem({ item }: { item: Book }) {
    return <BookCard book={item} />;
  }

  function renderEmpty() {
    return (
      <View style={styles.emptyWrap}>
        <Ionicons
          name="checkmark-circle-outline"
          size={48}
          color={colors.mutedForeground}
        />
        <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
          No history yet
        </Text>
        <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
          Returned books will appear here
        </Text>
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.header,
          {
            paddingTop: topPad + 16,
            borderBottomColor: colors.border,
            backgroundColor: colors.background,
          },
        ]}
      >
        <Text style={[styles.screenTitle, { color: colors.foreground }]}>
          Reading History
        </Text>
        {returned.length > 0 && (
          <View
            style={[
              styles.countBadge,
              { backgroundColor: colors.secondary, borderRadius: 20 },
            ]}
          >
            <Text
              style={[styles.countText, { color: colors.secondaryForeground }]}
            >
              {returned.length} returned
            </Text>
          </View>
        )}
      </View>

      <FlatList
        data={returned}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        ListEmptyComponent={renderEmpty}
        contentContainerStyle={[
          styles.list,
          {
            paddingBottom:
              Platform.OS === "web" ? 34 + 80 : insets.bottom + 100,
          },
        ]}
        showsVerticalScrollIndicator={false}
        scrollEnabled={!!returned.length}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
  },
  screenTitle: {
    fontSize: 22,
    fontFamily: "Inter_700Bold",
  },
  countBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  countText: {
    fontSize: 12,
    fontFamily: "Inter_500Medium",
  },
  list: { padding: 16 },
  emptyWrap: {
    alignItems: "center",
    paddingTop: 80,
    gap: 10,
    paddingHorizontal: 32,
  },
  emptyTitle: {
    fontSize: 17,
    fontFamily: "Inter_600SemiBold",
    marginTop: 8,
  },
  emptyText: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
  },
});
