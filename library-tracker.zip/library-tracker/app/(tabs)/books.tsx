import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React, { useMemo, useState } from "react";
import {
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { BookCard } from "@/components/BookCard";
import { Book, getDaysUntilDue, useBooks } from "@/context/BooksContext";
import { useColors } from "@/hooks/useColors";

type Filter = "all" | "soon" | "overdue";

const FILTERS: { key: Filter; label: string }[] = [
  { key: "all", label: "All" },
  { key: "soon", label: "Due Soon" },
  { key: "overdue", label: "Overdue" },
];

export default function BooksScreen() {
  const colors = useColors();
  const { books } = useBooks();
  const [filter, setFilter] = useState<Filter>("all");
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const active = useMemo(
    () => books.filter((b) => b.status === "active"),
    [books]
  );

  const filtered = useMemo(() => {
    if (filter === "soon")
      return active.filter((b) => {
        const d = getDaysUntilDue(b.dueDate);
        return d >= 0 && d <= 3;
      });
    if (filter === "overdue")
      return active.filter((b) => getDaysUntilDue(b.dueDate) < 0);
    return active;
  }, [active, filter]);

  const sorted = useMemo(
    () =>
      [...filtered].sort(
        (a, b) =>
          new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
      ),
    [filtered]
  );

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  function renderEmpty() {
    return (
      <View style={styles.emptyWrap}>
        <Ionicons name="book-outline" size={48} color={colors.mutedForeground} />
        <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
          {filter === "all" ? "No active books" : `No ${filter === "soon" ? "due soon" : "overdue"} books`}
        </Text>
        <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
          {filter === "all"
            ? "Add a book to start tracking"
            : "You're all caught up"}
        </Text>
        {filter === "all" && (
          <Pressable
            onPress={() => router.push("/(tabs)/add")}
            style={({ pressed }) => [
              styles.addBtn,
              { backgroundColor: colors.primary, borderRadius: colors.radius },
              pressed && { opacity: 0.8 },
            ]}
          >
            <Text style={[styles.addBtnText, { color: colors.primaryForeground }]}>
              Add a book
            </Text>
          </Pressable>
        )}
      </View>
    );
  }

  function renderItem({ item }: { item: Book }) {
    return <BookCard book={item} />;
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View
        style={[
          styles.header,
          {
            paddingTop: topPad + 16,
            borderBottomColor: colors.border,
            backgroundColor: colors.background,
          },
        ]}
      >
        <Text style={[styles.screenTitle, { color: colors.foreground }]}>
          Borrowed Books
        </Text>
        <Pressable
          onPress={() => router.push("/(tabs)/add")}
          style={({ pressed }) => [pressed && { opacity: 0.7 }]}
        >
          <Ionicons name="add-circle" size={28} color={colors.primary} />
        </Pressable>
      </View>

      {/* Filters */}
      <View style={[styles.filters, { borderBottomColor: colors.border }]}>
        {FILTERS.map((f) => (
          <Pressable
            key={f.key}
            onPress={() => setFilter(f.key)}
            style={({ pressed }) => [
              styles.filterBtn,
              {
                backgroundColor:
                  filter === f.key ? colors.primary : "transparent",
                borderRadius: 20,
              },
              pressed && { opacity: 0.8 },
            ]}
          >
            <Text
              style={[
                styles.filterText,
                {
                  color:
                    filter === f.key
                      ? colors.primaryForeground
                      : colors.mutedForeground,
                  fontFamily:
                    filter === f.key
                      ? "Inter_600SemiBold"
                      : "Inter_400Regular",
                },
              ]}
            >
              {f.label}
            </Text>
          </Pressable>
        ))}
      </View>

      <FlatList
        data={sorted}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        ListEmptyComponent={renderEmpty}
        contentContainerStyle={[
          styles.list,
          {
            paddingBottom:
              Platform.OS === "web" ? 34 + 80 : insets.bottom + 100,
          },
        ]}
        showsVerticalScrollIndicator={false}
        scrollEnabled={!!sorted.length}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
  },
  screenTitle: {
    fontSize: 22,
    fontFamily: "Inter_700Bold",
  },
  filters: {
    flexDirection: "row",
    paddingHorizontal: 12,
    paddingVertical: 10,
    gap: 6,
    borderBottomWidth: 1,
  },
  filterBtn: {
    paddingHorizontal: 14,
    paddingVertical: 6,
  },
  filterText: { fontSize: 13 },
  list: { padding: 16 },
  emptyWrap: {
    alignItems: "center",
    paddingTop: 80,
    gap: 10,
    paddingHorizontal: 32,
  },
  emptyTitle: {
    fontSize: 17,
    fontFamily: "Inter_600SemiBold",
    marginTop: 8,
  },
  emptyText: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
  },
  addBtn: {
    marginTop: 12,
    paddingHorizontal: 24,
    paddingVertical: 12,
  },
  addBtnText: {
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
  },
});
