import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useBooks } from "@/context/BooksContext";
import { useColors } from "@/hooks/useColors";

function formatDateForInput(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function parseDateInput(str: string): Date | null {
  const parts = str.split("-");
  if (parts.length !== 3) return null;
  const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
  if (isNaN(d.getTime())) return null;
  return d;
}

export default function AddScreen() {
  const colors = useColors();
  const { addBook } = useBooks();
  const insets = useSafeAreaInsets();

  const today = new Date();
  const twoWeeks = new Date(today.getTime() + 14 * 24 * 60 * 60 * 1000);

  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [library, setLibrary] = useState("");
  const [borrowDate, setBorrowDate] = useState(formatDateForInput(today));
  const [dueDate, setDueDate] = useState(formatDateForInput(twoWeeks));
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  async function handleSave() {
    if (!title.trim()) {
      Alert.alert("Missing info", "Please enter the book title.");
      return;
    }
    if (!author.trim()) {
      Alert.alert("Missing info", "Please enter the author name.");
      return;
    }
    if (!library.trim()) {
      Alert.alert("Missing info", "Please enter the library name.");
      return;
    }
    const bDate = parseDateInput(borrowDate);
    const dDate = parseDateInput(dueDate);
    if (!bDate) {
      Alert.alert("Invalid date", "Please enter borrow date as YYYY-MM-DD.");
      return;
    }
    if (!dDate) {
      Alert.alert("Invalid date", "Please enter due date as YYYY-MM-DD.");
      return;
    }
    if (dDate <= bDate) {
      Alert.alert("Invalid date", "Due date must be after borrow date.");
      return;
    }

    setSaving(true);
    try {
      await addBook({
        title: title.trim(),
        author: author.trim(),
        library: library.trim(),
        borrowDate: bDate.toISOString(),
        dueDate: dDate.toISOString(),
        notes: notes.trim(),
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setTitle("");
      setAuthor("");
      setLibrary("");
      setBorrowDate(formatDateForInput(new Date()));
      setDueDate(
        formatDateForInput(
          new Date(Date.now() + 14 * 24 * 60 * 60 * 1000)
        )
      );
      setNotes("");
      Alert.alert("Saved!", `"${title.trim()}" has been added to your library.`);
    } finally {
      setSaving(false);
    }
  }

  const inputStyle = [
    styles.input,
    {
      backgroundColor: colors.card,
      borderColor: colors.border,
      color: colors.foreground,
      borderRadius: colors.radius,
      fontFamily: "Inter_400Regular" as const,
    },
  ];

  const labelStyle = [styles.label, { color: colors.mutedForeground }];

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={[
        styles.content,
        {
          paddingTop: topPad + 16,
          paddingBottom:
            Platform.OS === "web" ? 34 + 80 : insets.bottom + 100,
        },
      ]}
      keyboardShouldPersistTaps="handled"
      showsVerticalScrollIndicator={false}
    >
      <Text style={[styles.screenTitle, { color: colors.foreground }]}>
        Add Book
      </Text>
      <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
        Track a newly borrowed book
      </Text>

      <View style={styles.form}>
        <View style={styles.field}>
          <Text style={labelStyle}>Book Title *</Text>
          <TextInput
            style={inputStyle}
            value={title}
            onChangeText={setTitle}
            placeholder="e.g. The Great Gatsby"
            placeholderTextColor={colors.mutedForeground}
            returnKeyType="next"
          />
        </View>

        <View style={styles.field}>
          <Text style={labelStyle}>Author *</Text>
          <TextInput
            style={inputStyle}
            value={author}
            onChangeText={setAuthor}
            placeholder="e.g. F. Scott Fitzgerald"
            placeholderTextColor={colors.mutedForeground}
            returnKeyType="next"
          />
        </View>

        <View style={styles.field}>
          <Text style={labelStyle}>Library *</Text>
          <TextInput
            style={inputStyle}
            value={library}
            onChangeText={setLibrary}
            placeholder="e.g. City Central Library"
            placeholderTextColor={colors.mutedForeground}
            returnKeyType="next"
          />
        </View>

        <View style={styles.row}>
          <View style={[styles.field, { flex: 1 }]}>
            <Text style={labelStyle}>Borrow Date</Text>
            <TextInput
              style={inputStyle}
              value={borrowDate}
              onChangeText={setBorrowDate}
              placeholder="YYYY-MM-DD"
              placeholderTextColor={colors.mutedForeground}
              keyboardType="numbers-and-punctuation"
              returnKeyType="next"
            />
          </View>
          <View style={[styles.field, { flex: 1 }]}>
            <Text style={labelStyle}>Due Date</Text>
            <TextInput
              style={inputStyle}
              value={dueDate}
              onChangeText={setDueDate}
              placeholder="YYYY-MM-DD"
              placeholderTextColor={colors.mutedForeground}
              keyboardType="numbers-and-punctuation"
              returnKeyType="next"
            />
          </View>
        </View>

        <View style={styles.field}>
          <Text style={labelStyle}>Notes (optional)</Text>
          <TextInput
            style={[inputStyle, styles.notesInput]}
            value={notes}
            onChangeText={setNotes}
            placeholder="Any notes about this book..."
            placeholderTextColor={colors.mutedForeground}
            multiline
            numberOfLines={3}
            textAlignVertical="top"
          />
        </View>

        <Pressable
          onPress={handleSave}
          disabled={saving}
          style={({ pressed }) => [
            styles.saveBtn,
            {
              backgroundColor: saving
                ? colors.muted
                : colors.primary,
              borderRadius: colors.radius,
            },
            pressed && { opacity: 0.85 },
          ]}
        >
          <Ionicons
            name="checkmark"
            size={20}
            color={saving ? colors.mutedForeground : colors.primaryForeground}
          />
          <Text
            style={[
              styles.saveBtnText,
              {
                color: saving
                  ? colors.mutedForeground
                  : colors.primaryForeground,
              },
            ]}
          >
            {saving ? "Saving..." : "Save Book"}
          </Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingHorizontal: 16 },
  screenTitle: {
    fontSize: 26,
    fontFamily: "Inter_700Bold",
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    marginBottom: 28,
  },
  form: { gap: 16 },
  field: { gap: 6 },
  label: {
    fontSize: 12,
    fontFamily: "Inter_500Medium",
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  input: {
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
  },
  notesInput: {
    height: 90,
    paddingTop: 12,
  },
  row: { flexDirection: "row", gap: 12 },
  saveBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 15,
    marginTop: 8,
  },
  saveBtnText: {
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
  },
});
