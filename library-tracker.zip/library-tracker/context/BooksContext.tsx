import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";

export interface Book {
  id: string;
  title: string;
  author: string;
  library: string;
  borrowDate: string;
  dueDate: string;
  notes: string;
  status: "active" | "returned";
  returnedDate?: string;
  coverColor: string;
}

interface BooksContextValue {
  books: Book[];
  loading: boolean;
  addBook: (
    book: Omit<Book, "id" | "status" | "coverColor">
  ) => Promise<void>;
  returnBook: (id: string) => Promise<void>;
  deleteBook: (id: string) => Promise<void>;
  updateBook: (id: string, updates: Partial<Book>) => Promise<void>;
}

const BooksContext = createContext<BooksContextValue | null>(null);

const STORAGE_KEY = "@library_tracker_books";

const COVER_COLORS = [
  "#8B4513",
  "#2E4057",
  "#1B4332",
  "#7B2D8B",
  "#C0392B",
  "#16213E",
  "#4A235A",
  "#1A5276",
  "#784212",
  "#0B5345",
  "#922B21",
  "#1F4E79",
  "#6E2F0B",
  "#145A32",
  "#512E5F",
];

function getRandomCoverColor(): string {
  return COVER_COLORS[Math.floor(Math.random() * COVER_COLORS.length)];
}

export function getDaysUntilDue(dueDate: string): number {
  const due = new Date(dueDate);
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  due.setHours(0, 0, 0, 0);
  return Math.round((due.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
}

export function getBookStatus(book: Book): {
  label: string;
  color: string;
  type: "returned" | "overdue" | "today" | "soon" | "ok";
} {
  if (book.status === "returned")
    return { label: "Returned", color: "#27AE60", type: "returned" };
  const days = getDaysUntilDue(book.dueDate);
  if (days < 0)
    return {
      label: `${Math.abs(days)}d overdue`,
      color: "#C0392B",
      type: "overdue",
    };
  if (days === 0)
    return { label: "Due today", color: "#E67E22", type: "today" };
  if (days <= 3)
    return { label: `${days}d left`, color: "#E67E22", type: "soon" };
  return { label: `${days}d left`, color: "#27AE60", type: "ok" };
}

export function BooksProvider({ children }: { children: React.ReactNode }) {
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadBooks();
  }, []);

  async function loadBooks() {
    try {
      const data = await AsyncStorage.getItem(STORAGE_KEY);
      if (data) {
        setBooks(JSON.parse(data));
      }
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  async function saveBooks(newBooks: Book[]) {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(newBooks));
    setBooks(newBooks);
  }

  const addBook = useCallback(
    async (bookData: Omit<Book, "id" | "status" | "coverColor">) => {
      const newBook: Book = {
        ...bookData,
        id:
          Date.now().toString() +
          Math.random().toString(36).substr(2, 9),
        status: "active",
        coverColor: getRandomCoverColor(),
      };
      const updated = [newBook, ...books];
      await saveBooks(updated);
    },
    [books]
  );

  const returnBook = useCallback(
    async (id: string) => {
      const updated = books.map((b) =>
        b.id === id
          ? {
              ...b,
              status: "returned" as const,
              returnedDate: new Date().toISOString(),
            }
          : b
      );
      await saveBooks(updated);
    },
    [books]
  );

  const deleteBook = useCallback(
    async (id: string) => {
      const updated = books.filter((b) => b.id !== id);
      await saveBooks(updated);
    },
    [books]
  );

  const updateBook = useCallback(
    async (id: string, updates: Partial<Book>) => {
      const updated = books.map((b) =>
        b.id === id ? { ...b, ...updates } : b
      );
      await saveBooks(updated);
    },
    [books]
  );

  return (
    <BooksContext.Provider
      value={{ books, loading, addBook, returnBook, deleteBook, updateBook }}
    >
      {children}
    </BooksContext.Provider>
  );
}

export function useBooks() {
  const ctx = useContext(BooksContext);
  if (!ctx) throw new Error("useBooks must be used within BooksProvider");
  return ctx;
}
